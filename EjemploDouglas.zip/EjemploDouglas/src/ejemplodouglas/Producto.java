
package ejemplodouglas;


public class Producto {
    String nombre;
    String fechaVencimiento;
    int cantidad;
    
    public void advertencia(){
        System.out.println("Cuidad al abrirlo");
    }
}
