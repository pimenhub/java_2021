
package ejemplopoo;

import java.util.Scanner;


public class EjemploPOO {

  
    public static void main(String[] args) {
        //Declaracion de una objeto (Instacia de una clase)
        Scanner sc = new Scanner(System.in);

        Vehiculo sedan = new Vehiculo();
//        
//        sedan.marca = "Mazda";
//        sedan.pasajeros = 5;
//        sedan.velocidad = 200;        
//        
//        System.out.println("Marca: "+sedan.marca+
//                " Pasajeros: "+sedan.pasajeros+" Velocidad: "+sedan.velocidad);
//        sedan.arranca();
//        sedan.apagar();
//        System.out.println("-----------------------");
//        
//        Vehiculo pickup = new Vehiculo();
//        pickup.marca = "Toyata";
//        pickup.pasajeros = 2;
//        pickup.velocidad = 150;
//        
//        System.out.println("Marca: "+pickup.marca+
//                " Pasajeros: "+pickup.pasajeros+" Velocidad: "+pickup.velocidad);
//        pickup.arranca();
//        pickup.apagar();

//          Vehiculo.arranca();
//          Vehiculo.marca = "";
    }
    
}
