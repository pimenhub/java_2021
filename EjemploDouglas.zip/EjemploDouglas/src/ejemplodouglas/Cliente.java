
package ejemplodouglas;


public class Cliente {
    String nom;
    String ape;
    int edad;
    
    public void comprar(){
        System.out.println("El cliente compra un poducto");
    }
    
}
